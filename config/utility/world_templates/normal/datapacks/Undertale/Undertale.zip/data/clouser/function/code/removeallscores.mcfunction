##
 # removeallscores.mcfunction
 # 
 #
 # Created by .
##
