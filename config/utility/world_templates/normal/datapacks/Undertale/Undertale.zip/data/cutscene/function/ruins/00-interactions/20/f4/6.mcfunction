##
 # 6.mcfunction
 # 
 #
 # Created by .
##

scoreboard players set @s canDance 0
scoreboard players set @s canProgress 0
scoreboard players set @s interact 36

textBox style 13069000 image texture minecraft:block/battle/blank
textBox display @s 13069000 ""
textBox display @s 13069003 [{"text": "* (Yeah, your \"full screen\"\n  button is actually \"","font":"customfonts:determination"},{"keybind":"key.fullscreen","font":"customfonts:determination"},{"text": "\")","font":"customfonts:determination"}]

scoreboard players set #canmove cutscene 0

execute scheduled 14t if score @s interact matches 36 run scoreboard players set @s canProgress 1