##
 # blank.mcfunction
 # 
 #
 # Created by .
##
